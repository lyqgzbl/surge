float GetNoise(vec2 uv, float scale, float detail, float roughness, float distortion)
{
    vec2 p = uv * scale;
    if (distortion != 0.0) {
        p += vec2(snoise(p + random_vec2_offset(0.0)) * distortion,
                snoise(p + random_vec2_offset(1.0)) * distortion);
    }
    float value = fractal_noise(p, detail, roughness);
    return value;
}

void main()
{
    vec2 uv = cron_tex_coord;

    float noise_0 = GetNoise(uv, scale_0, detail_0, roughness_0, distortion_0);
    float noise_1 = GetNoise(uv, scale_1, detail_1, roughness_1, distortion_1);
    float noise_2 = GetNoise(uv, scale_2, detail_2, roughness_2, distortion_2);
    float noise_3 = GetNoise(uv, scale_3, detail_3, roughness_3, distortion_3);

    cron_output = vec4(noise_0, noise_1, noise_2, noise_3);
}