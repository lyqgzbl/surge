// 听字幕（audio-only / 听视频）模式专用的背景模糊 shader：把视频封面模糊成字幕层背后的朦胧背景。
// 调用方：src/danmaku/business/demand/event/vcs/audio_only_subtitle_vc.ts（AudioOnlySubtitleVC）。
// 实现为可分离的一维 9-tap 高斯模糊，由调用方分横/纵两个 pass、多级递增半径累积出大范围模糊。

const float weights[5] = float[](0.20236, 0.179044, 0.124009, 0.067234, 0.028532);

vec2 calculateScale(ivec2 texSize) {
  return vec2(1.0 / float(texSize.x), 1.0 / float(texSize.y));
}

vec2 calculateOffsetX(float x) {
  return vec2(u_radius * x, 0.0);
}

vec2 calculateOffsetY(float y) {
  return vec2(0.0, u_radius * y);
}

void main() {
  ivec2 texture_size = textureSize(cron_texture, 0);
  vec2 scale = calculateScale(texture_size);
  vec2 offset = vec2(0.0);
  if (u_direction > 0.5) {
    offset = calculateOffsetX(scale.x);
  } else {
    offset = calculateOffsetY(scale.y);
  }
  vec2 start = cron_tex_coord - offset * 4.0;
  vec4 color = vec4(0.0);
  color += texture2D(cron_texture, start) * weights[4]; start += offset;
  color += texture2D(cron_texture, start) * weights[3]; start += offset;
  color += texture2D(cron_texture, start) * weights[2]; start += offset;
  color += texture2D(cron_texture, start) * weights[1]; start += offset;
  color += texture2D(cron_texture, start) * weights[0]; start += offset;
  color += texture2D(cron_texture, start) * weights[1]; start += offset;
  color += texture2D(cron_texture, start) * weights[2]; start += offset;
  color += texture2D(cron_texture, start) * weights[3]; start += offset;
  color += texture2D(cron_texture, start) * weights[4];
  cron_output = color;
}
