void main() {
  cron_output = vec4(texture2D(cron_texture, cron_tex_coord).r);
}