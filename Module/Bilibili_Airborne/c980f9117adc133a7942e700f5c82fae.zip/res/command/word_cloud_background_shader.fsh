void main() {
  float alpha = min(texture2D(cron_texture, cron_tex_coord).a, 0.4);
  cron_output = alpha * vec4(0.0, 0.0, 0.0, 1.0);
}