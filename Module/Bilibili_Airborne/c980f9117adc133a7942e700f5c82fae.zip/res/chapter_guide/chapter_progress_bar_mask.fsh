void main() {
  cron_output = texture2D(cron_texture, cron_tex_coord) * step(cron_tex_coord.x, progress);
}